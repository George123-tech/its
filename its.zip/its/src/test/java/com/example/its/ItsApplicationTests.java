package com.example.its;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItsApplicationTests {

	@Test
	void contextLoads() {
	}

}
